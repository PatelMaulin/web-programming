# Theme Switcher – Maulin Patel

A portfolio page with a light theme and an alternate dark theme, built with
**CSS variables** and **vanilla JavaScript**, based on
[codedgar's dark theme tutorial](https://dev.to/codedgar/how-to-create-a-dark-theme-system-in-5-minutes-or-less-with-vanilla-js-2922).

## Files
- `index.html` – page structure and the `#theme_toggler` button
- `style.css` – light colors in `:root`, dark colors in `.dark_mode`
- `script.js` – toggles the class, saves it to `localStorage`, syncs tabs

## How it works
1. Every color is a CSS variable (`--body-bg`, `--text-color`, …).
2. `.dark_mode` redefines those variables.
3. Clicking the button toggles `dark_mode` on `<body>` and saves it as `website_theme` in `localStorage`.
4. On load, `retrieve_theme()` re-applies the saved theme; a `storage` listener keeps other tabs in sync.

## Run it
Open `index.html` in a browser, or view the live page via GitHub Pages.
